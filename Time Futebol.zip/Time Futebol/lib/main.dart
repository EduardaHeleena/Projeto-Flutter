import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'timefutebol.dart';

void main() {
  runApp(const TimesFutebolApp());
}

class TimesFutebolApp extends StatelessWidget {
  const TimesFutebolApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Times de Futebol',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[200],
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 18, fontFamily: 'Roboto', color: Colors.black),
          titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Roboto'),
        ),
      ),
      home: const PaginaInicial(), // Página inicial
    );
  }
}

// Página inicial
class PaginaInicial extends StatelessWidget {
  const PaginaInicial({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E21), // Preto quase azul-marinho
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Título principal
            Text(
              "WORLD TEAMS",
              style: TextStyle(
                fontSize: 40, // Aumentado o tamanho da fonte
                fontWeight: FontWeight.bold,
                color: Colors.tealAccent[400],
                letterSpacing: 2.0,
              ),
            ),
            const SizedBox(height: 10),

            // Subtítulo
            const Text(
              "Seu gerenciador de times de ponta a ponta.",
              style: TextStyle(fontSize: 16, color: Colors.grey, fontStyle: FontStyle.italic),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),

            // Botão
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                backgroundColor: Colors.teal, // Cor do botão
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ListaTimesFutebol()),
                );
              },
              child: const Text(
                "ACESSAR TIMES",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white, // Cor do texto do botão alterada para branco
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Página de lista de times
class ListaTimesFutebol extends StatefulWidget {
  const ListaTimesFutebol({Key? key}) : super(key: key);

  @override
  _ListaTimesFutebolState createState() => _ListaTimesFutebolState();
}

class _ListaTimesFutebolState extends State<ListaTimesFutebol> {
  List<TimeFutebol> timesFutebol = [];
  bool isLoading = true;

  Future<void> fetchTimesFutebol() async {
    final url = Uri.parse('https://arquivos.ectare.com.br/timesfutebol.json');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(utf8.decode(response.bodyBytes));
        setState(() {
          timesFutebol = (data as List).map((json) => TimeFutebol.fromJson(json)).toList();
          isLoading = false;
        });
      } else {
        throw Exception('Falha ao carregar dados da API');
      }
    } catch (error) {
      print('Erro ao buscar times de futebol: $error');
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchTimesFutebol();
  }

  String getImagePath(String nome) {
    switch (nome.toLowerCase()) {
      case 'flamengo':
        return 'assets/images/flamengo.png';
      case 'palmeiras':
        return 'assets/images/palmeiras.png';
      case 'corinthians':
        return 'assets/images/corinthians.png';
      case 'santos':
        return 'assets/images/santos.png';
      case 'grêmio':
        return 'assets/images/gremio.png';
      case 'vasco da gama':
        return 'assets/images/vascogama.png';
      case 'são paulo':
        return 'assets/images/saopaulo.png';
      case 'internacional':
        return 'assets/images/internacional.png';
      case 'cruzeiro':
        return 'assets/images/cruzeiro.png';
      case 'atlético mineiro':
        return 'assets/images/atleticomineiro.png';
      default:
        return 'assets/images/default.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Times de Futebol',
          style: Theme.of(context).textTheme.titleLarge!.copyWith(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
        elevation: 5,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: timesFutebol.length,
              itemBuilder: (context, index) {
                final time = timesFutebol[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    title: Text(
                      time.nome,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      '${time.estado} - Fundado em ${time.fundacao}\nTítulos Nacionais: ${time.tituloNacional}',
                      style: const TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.asset(
                        getImagePath(time.nome),
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(Icons.error, color: Colors.red, size: 50);
                        },
                      ),
                    ),
                    trailing: const Icon(Icons.sports_soccer, color: Colors.blue),
                  ),
                );
              },
            ),
    );
  }
}
