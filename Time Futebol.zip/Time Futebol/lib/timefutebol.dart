// lib/timefutebol.dart
class TimeFutebol {
  final String nome;
  final String estado;
  final int fundacao;
  final int tituloNacional;

  // Construtor da classe TimeFutebol
  TimeFutebol({
    required this.nome,
    required this.estado,
    required this.fundacao,
    required this.tituloNacional,
  });

  
  factory TimeFutebol.fromJson(Map<String, dynamic> json) {
    return TimeFutebol(
      nome: json['nome'] ?? 'Desconhecido',  
      estado: json['estado'] ?? 'Não informado',  
      fundacao: json['fundacao'] ?? 0,  
      tituloNacional: json['titulo_nacional'] ?? 0,  
    );
  }
}
