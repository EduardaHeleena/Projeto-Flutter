// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:myapp/main.dart';

void main() {
  testWidgets('Testa renderização básica do aplicativo', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const TimesFutebolApp());

    // Verifica se o título "Times de Futebol" está presente.
    expect(find.text('Times de Futebol'), findsOneWidget);

    // Verifica se o indicador de carregamento é exibido inicialmente.
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // Aguarda o carregamento dos dados (simula o FutureBuilder completando).
    await tester.pumpAndSettle();

    // Verifica se pelo menos um item da lista está renderizado.
    expect(find.byType(ListTile), findsWidgets);

    // Interage com um dos itens da lista (por exemplo, o primeiro ListTile).
    final firstListTile = find.byType(ListTile).first;
    expect(firstListTile, findsOneWidget);

    // Verifica se o ícone de futebol está presente no ListTile.
    expect(find.byIcon(Icons.sports_soccer), findsWidgets);

    // Verifica se a imagem do logo do time é carregada.
    expect(find.byType(Image), findsWidgets);

    // Verifica se o nome do time está sendo exibido.
    expect(find.textContaining('Flamengo'), findsOneWidget);  // Substitua por um nome real de time, se necessário
  });
}
